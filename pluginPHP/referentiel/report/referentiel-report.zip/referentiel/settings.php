<?php  // $Id: settings.php,v 1.1.2.1 2008/11/26 20:58:07 skodak Exp $
$ADMIN->add('reports', new admin_externalpage('reportreferentiel', get_string('referentiel', 'referentiel'), "$CFG->wwwroot/$CFG->admin/report/referentiel/index.php", 'moodle/site:config'));
?>